/* globals Chart:false, feather:false */

(function () {
    'use strict'

    feather.replace()
} ())